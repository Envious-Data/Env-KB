# Envious Keyboards

Various RP2040 based keyboard designs intended to be cheap.

* Keyboard Maintainer: [Envious-Data](https://github.com/envious-data)
* Hardware Supported:
  * EnvKB TKL "Delirium"
  * EnvKB 65M
  * EnvKB MCRO
  * EnvKB 60F
* Hardware Availability: 
  * Direct Mesage
