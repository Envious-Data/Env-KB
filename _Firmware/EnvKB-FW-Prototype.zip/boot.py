import supervisor

supervisor.set_next_stack_limit(4096 + 1024)
